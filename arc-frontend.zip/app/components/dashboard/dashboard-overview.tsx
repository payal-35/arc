"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "~/components/ui/card"
import {
  FileText,
  MessageSquare,
  ShieldCheck,
  AlertTriangle,
  CheckCircle,
  Clock,
  Key,
  Globe,
  Loader2,
} from "lucide-react"
import { Button } from "~/components/ui/button"
import { Progress } from "~/components/ui/progress"
import { toast } from "~/components/ui/use-toast"

interface AdminInfo {
  admin_id: string
  tenant_id: string
  iat: number
  exp: number
}

interface DashboardStats {
  totalPurposes: number
  activePurposes: number
  totalConsents: number
  consentRate: number
  openGrievances: number
  resolvedGrievances: number
  dpdpComplianceScore: number
}

export default function DashboardOverview() {
  const [stats, setStats] = useState<DashboardStats>({
    totalPurposes: 0,
    activePurposes: 0,
    totalConsents: 0,
    consentRate: 0,
    openGrievances: 0,
    resolvedGrievances: 0,
    dpdpComplianceScore: 0,
  })
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)

  useEffect(() => {
    // In a real implementation, this would fetch actual data from your API
    // For now, we'll simulate loading and then set some example data
    const timer = setTimeout(() => {
      setStats({
        totalPurposes: 12,
        activePurposes: 8,
        totalConsents: 1458,
        consentRate: 87,
        openGrievances: 3,
        resolvedGrievances: 24,
        dpdpComplianceScore: 92,
      })
      setLoading(false)
    }, 1000)

    return () => clearTimeout(timer)
  }, [])

  const handleRefresh = () => {
    setRefreshing(true)
    // Simulate API call
    setTimeout(() => {
      setStats({
        totalPurposes: 12,
        activePurposes: 8,
        totalConsents: 1472, // Updated value
        consentRate: 88, // Updated value
        openGrievances: 2, // Updated value
        resolvedGrievances: 25, // Updated value
        dpdpComplianceScore: 93, // Updated value
      })
      setRefreshing(false)
      toast({
        title: "Dashboard Refreshed",
        description: "Dashboard data has been updated successfully.",
      })
    }, 1500)
  }

  const handleViewFullReport = () => {
    toast({
      title: "Compliance Report",
      description: "Generating full compliance report...",
    })
    // Simulate report generation
    setTimeout(() => {
      toast({
        title: "Report Ready",
        description: "Your compliance report is ready to view.",
      })
    }, 2000)
  }

  const handleViewAllActivities = () => {
    toast({
      title: "All Activities",
      description: "Loading all activities...",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Last updated: {new Date().toLocaleTimeString()}</span>
          <Button variant="outline" size="sm" onClick={handleRefresh} disabled={refreshing}>
            {refreshing ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Refreshing...
              </>
            ) : (
              "Refresh"
            )}
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="bg-gradient-to-br from-blue-500/10 via-background to-blue-500/5 border-blue-500/20 hover:shadow-md transition-all">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Purposes</CardTitle>
            <FileText className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-blue-500">{loading ? "-" : stats.totalPurposes}</div>
            <p className="text-xs text-muted-foreground">
              {loading ? "Loading..." : `${stats.activePurposes} active purposes`}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-500/10 via-background to-green-500/5 border-green-500/20 hover:shadow-md transition-all">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Consent Rate</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{loading ? "-" : `${stats.consentRate}%`}</div>
            <p className="text-xs text-muted-foreground">
              {loading ? "Loading..." : `${stats.totalConsents} total consents`}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500/10 via-background to-amber-500/5 border-amber-500/20 hover:shadow-md transition-all">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Grievances</CardTitle>
            <MessageSquare className="h-4 w-4 text-amber-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-amber-500">{loading ? "-" : stats.openGrievances}</div>
            <p className="text-xs text-muted-foreground">
              {loading ? "Loading..." : `${stats.resolvedGrievances} resolved`}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-500/10 via-background to-purple-500/5 border-purple-500/20 hover:shadow-md transition-all">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">DPDP Compliance</CardTitle>
            <ShieldCheck className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-purple-500">{loading ? "-" : `${stats.dpdpComplianceScore}%`}</div>
            <Progress
              value={loading ? 0 : stats.dpdpComplianceScore}
              className="h-2 mt-2 bg-purple-100 dark:bg-purple-950"
            >
              <div className="h-full bg-purple-500" style={{ width: `${loading ? 0 : stats.dpdpComplianceScore}%` }} />
            </Progress>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card className="md:col-span-2 bg-gradient-to-br from-primary/10 via-background to-secondary/10 border-primary/20 hover:shadow-md transition-all">
          <CardHeader>
            <CardTitle className="text-primary">DPDP Compliance Overview</CardTitle>
            <CardDescription>
              Your organization's compliance with Digital Personal Data Protection regulations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-2 rounded-md bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-900">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Consent Management</span>
                </div>
                <span className="text-green-500 font-medium">Compliant</span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-md bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-900">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Data Access Requests</span>
                </div>
                <span className="text-green-500 font-medium">Compliant</span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-md bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-900">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span>Grievance Handling</span>
                </div>
                <span className="text-green-500 font-medium">Compliant</span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-md bg-yellow-50 dark:bg-yellow-950/30 border border-yellow-200 dark:border-yellow-900">
                <div className="flex items-center">
                  <AlertTriangle className="h-5 w-5 text-yellow-500 mr-2" />
                  <span>Data Retention Policies</span>
                </div>
                <span className="text-yellow-500 font-medium">Needs Review</span>
              </div>

              <div className="flex items-center justify-between p-2 rounded-md bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900">
                <div className="flex items-center">
                  <Clock className="h-5 w-5 text-blue-500 mr-2" />
                  <span>Periodic Consent Review</span>
                </div>
                <span className="text-blue-500 font-medium">In Progress</span>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button variant="default" className="w-full bg-primary hover:bg-primary/90" onClick={handleViewFullReport}>
              View Full Compliance Report
            </Button>
          </CardFooter>
        </Card>

        <Card className="bg-gradient-to-br from-secondary/10 via-background to-primary/5 border-secondary/20 hover:shadow-md transition-all">
          <CardHeader>
            <CardTitle className="text-secondary-foreground">Recent Activities</CardTitle>
            <CardDescription>Latest actions in your organization</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="rounded-md bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-900 pl-4 py-2 flex items-center">
                <div className="h-8 w-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center mr-3">
                  <FileText className="h-4 w-4 text-blue-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">New purpose created</p>
                  <p className="text-xs text-muted-foreground">Today, 10:30 AM</p>
                </div>
              </div>

              <div className="rounded-md bg-green-50 dark:bg-green-950/30 border border-green-200 dark:border-green-900 pl-4 py-2 flex items-center">
                <div className="h-8 w-8 rounded-full bg-green-100 dark:bg-green-900 flex items-center justify-center mr-3">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Grievance resolved</p>
                  <p className="text-xs text-muted-foreground">Yesterday, 4:15 PM</p>
                </div>
              </div>

              <div className="rounded-md bg-purple-50 dark:bg-purple-950/30 border border-purple-200 dark:border-purple-900 pl-4 py-2 flex items-center">
                <div className="h-8 w-8 rounded-full bg-purple-100 dark:bg-purple-900 flex items-center justify-center mr-3">
                  <Key className="h-4 w-4 text-purple-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">API key generated</p>
                  <p className="text-xs text-muted-foreground">Yesterday, 2:45 PM</p>
                </div>
              </div>

              <div className="rounded-md bg-orange-50 dark:bg-orange-950/30 border border-orange-200 dark:border-orange-900 pl-4 py-2 flex items-center">
                <div className="h-8 w-8 rounded-full bg-orange-100 dark:bg-orange-900 flex items-center justify-center mr-3">
                  <Globe className="h-4 w-4 text-orange-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">Webhook configured</p>
                  <p className="text-xs text-muted-foreground">May 21, 11:20 AM</p>
                </div>
              </div>

              <div className="rounded-md bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 pl-4 py-2 flex items-center">
                <div className="h-8 w-8 rounded-full bg-red-100 dark:bg-red-900 flex items-center justify-center mr-3">
                  <MessageSquare className="h-4 w-4 text-red-500" />
                </div>
                <div>
                  <p className="text-sm font-medium">New grievance submitted</p>
                  <p className="text-xs text-muted-foreground">May 20, 9:05 AM</p>
                </div>
              </div>
            </div>
          </CardContent>
          <CardFooter>
            <Button
              variant="default"
              className="w-full bg-secondary hover:bg-secondary/90"
              onClick={handleViewAllActivities}
            >
              View All Activities
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
